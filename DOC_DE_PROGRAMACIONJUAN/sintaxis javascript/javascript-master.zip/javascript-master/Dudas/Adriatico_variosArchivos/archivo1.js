function mensaje1(){
	alert ("Este es el archivo 1");
}