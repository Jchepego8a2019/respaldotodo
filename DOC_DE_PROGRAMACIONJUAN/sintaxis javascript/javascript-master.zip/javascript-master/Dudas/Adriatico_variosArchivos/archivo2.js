function mensaje2(){
	alert ("Este es el archivo 2");
}