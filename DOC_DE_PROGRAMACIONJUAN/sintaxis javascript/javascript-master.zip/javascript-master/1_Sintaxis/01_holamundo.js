function holamundo(){
	alert("Hola, mundo");
	}